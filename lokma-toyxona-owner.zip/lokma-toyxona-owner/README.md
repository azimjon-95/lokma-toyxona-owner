# Lokma To'yxonalar — Owner App

To'yxona egasi va xodimlar uchun mobil boshqaruv ilovasi.

**Platformalar:** Android (Google Play) · iOS (App Store)  
**Stack:** Expo (React Native) + TypeScript + Expo Router

## Ekranlar

| Ekran | Tavsif |
|-------|--------|
| Login | Telefon + parol |
| SMS | Parolni tiklash / kod |
| Rol | To'yxona egasi / Xodim |
| Bosh sahifa | Bugungi tadbir, tushum, keyingi bron |
| Kalendar | Oy ko'rinishi + statuslar |
| Bronlar | Filtrlangan ro'yxat |
| Bron tafsiloti | Mijoz, menyu, to'lov, qo'ng'iroq |
| Mijozlar | Qidiruv + status |
| Menyu | Paketlar va taomlar |
| Moliya | Daromad / xarajat |
| Yangi ariza | 3 qadamli to'yxona arizasi |
| More | Profil, sozlamalar, chiqish |

## Ishga tushirish

```bash
cd lokma-toyxona-owner
npm install
npx expo start
```

Telefon yoki emulyatorda oching (Expo Go yoki development build).

### Demo login
- Istalgan telefon raqami (≥9 belgi)
- Parol ixtiyoriy
- SMS kod: istalgan 4+ raqam
- Rol tanlang → asosiy ekran

## Production build (EAS)

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android
eas build --platform ios
```

### Store talablari

**Android (Google Play)**
- `android.package`: `uz.lokma.toyxona.owner`
- Privacy Policy URL kerak
- Target API 34+
- 64-bit ABI

**iOS (App Store)**
- `ios.bundleIdentifier`: `uz.lokma.toyxona.owner`
- Privacy Nutrition Labels
- Camera / Photo library usage descriptions (app.json da bor)

## Loyiha tuzilmasi

```
app/
  (auth)/          Login, SMS, Rol
  (tabs)/          Asosiy 6 tab
  booking/[id]     Bron tafsiloti
  venue-apply/     Yangi to'yxona arizasi
  finance.tsx      Moliya
src/
  components/ui/   Button, Input, Card, Badge, Screen
  context/         AuthContext
  data/            Mock ma'lumotlar
  theme/           Ranglar, spacing
  types/           TypeScript tiplar
```

## Keyingi bosqich (backend ulash)

Hozir mock data. Real API uchun:
1. `src/services/api.ts` yarating
2. `lokma-toyxonalar-server` owner endpointlariga ulaning
3. AuthContext da SecureStore + JWT saqlang

## Dizayn

- Asosiy rang: gold/bronze `#B8860B`
- Fon: cream `#FBF7F0`
- Dizayn mockup asosida (Login → Home → Calendar → Bookings → Clients → Menu → Finance)
