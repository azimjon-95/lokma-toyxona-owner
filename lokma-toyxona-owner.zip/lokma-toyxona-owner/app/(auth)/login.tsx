import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { useAuth } from '@/src/context/AuthContext';

export default function LoginScreen() {
  const { login } = useAuth();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    setError('');
    if (!phone.trim()) {
      setError('Telefon raqamini kiriting');
      return;
    }
    setLoading(true);
    const ok = await login(phone.trim(), password);
    setLoading(false);
    if (ok) {
      router.push('/(auth)/sms');
    } else {
      setError("Kirish muvaffaqiyatsiz");
    }
  };

  return (
    <Screen scroll contentStyle={styles.content}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.flex}
      >
        {/* Hero */}
        <View style={styles.hero}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoIcon}>🏛️</Text>
          </View>
          <Text style={styles.brand}>Lokma</Text>
          <Text style={styles.brandSub}>To'yxonalar</Text>
          <Text style={styles.tagline}>
            To'yxonangizni oson boshqaring{'\n'}
            Bronlar, mijozlar, moliya, xodimlar — barchasi bir ilovada
          </Text>
        </View>

        {/* Form card */}
        <View style={styles.card}>
          <Input
            label="Telefon raqami"
            placeholder="+998 90 123 45 67"
            keyboardType="phone-pad"
            value={phone}
            onChangeText={setPhone}
            autoCapitalize="none"
          />
          <Input
            label="Parol"
            placeholder="••••••••"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
          />
          {error ? <Text style={styles.error}>{error}</Text> : null}

          <Button title="Kirish" onPress={handleLogin} loading={loading} />

          <TouchableOpacity
            style={styles.link}
            onPress={() => router.push('/(auth)/sms')}
          >
            <Text style={styles.linkText}>Parolni unutdingizmi?</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.applyBtn}
          onPress={() => router.push('/venue-apply')}
        >
          <Text style={styles.applyText}>
            Yangi to'yxona ochish uchun ariza qoldiring →
          </Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: {
    justifyContent: 'center',
    paddingTop: Spacing.xl,
  },
  hero: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  logoCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
    borderWidth: 2,
    borderColor: Colors.primaryLight,
  },
  logoIcon: { fontSize: 32 },
  brand: {
    fontSize: 32,
    fontWeight: '700',
    color: Colors.primaryDark,
    letterSpacing: 0.5,
  },
  brandSub: {
    fontSize: 18,
    fontWeight: '500',
    color: Colors.primary,
    marginBottom: Spacing.sm,
  },
  tagline: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: Spacing.lg,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 3,
  },
  error: {
    color: Colors.danger,
    fontSize: 13,
    marginBottom: Spacing.sm,
    textAlign: 'center',
  },
  link: {
    marginTop: Spacing.md,
    alignItems: 'center',
  },
  linkText: {
    color: Colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  applyBtn: {
    marginTop: Spacing.xl,
    alignItems: 'center',
    padding: Spacing.md,
  },
  applyText: {
    color: Colors.primaryDark,
    fontSize: 14,
    fontWeight: '600',
  },
});
