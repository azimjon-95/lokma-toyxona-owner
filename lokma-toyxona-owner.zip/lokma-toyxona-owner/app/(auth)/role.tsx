import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { useAuth } from '@/src/context/AuthContext';
import type { UserRole } from '@/src/types';

export default function RoleScreen() {
  const { setRole } = useAuth();
  const [selected, setSelected] = useState<UserRole | null>(null);

  const continueNext = () => {
    if (!selected) return;
    setRole(selected);
    router.replace('/(tabs)');
  };

  return (
    <Screen contentStyle={styles.content}>
      <Text style={styles.title}>Sizning hisobingiz</Text>
      <Text style={styles.subtitle}>Qaysi sifatda davom etasiz?</Text>

      <TouchableOpacity
        style={[styles.card, selected === 'owner' && styles.cardSelected]}
        onPress={() => setSelected('owner')}
        activeOpacity={0.85}
      >
        <View style={styles.iconBox}>
          <Text style={styles.emoji}>🏛️</Text>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle}>To'yxona egasi</Text>
          <Text style={styles.cardDesc}>
            To'yxonani boshqarish, bronlar, moliya, xodimlar va boshqalar
          </Text>
        </View>
        <View style={[styles.radio, selected === 'owner' && styles.radioOn]} />
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.card, selected === 'staff' && styles.cardSelected]}
        onPress={() => setSelected('staff')}
        activeOpacity={0.85}
      >
        <View style={styles.iconBox}>
          <Text style={styles.emoji}>👤</Text>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.cardTitle}>Xodim</Text>
          <Text style={styles.cardDesc}>
            Faqat o'z vazifalaringiz uchun kirish imkoniyati
          </Text>
        </View>
        <View style={[styles.radio, selected === 'staff' && styles.radioOn]} />
      </TouchableOpacity>

      <View style={styles.footer}>
        <Button title="Davom etish" onPress={continueNext} disabled={!selected} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.xxl },
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: Colors.text,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 15,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginTop: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    borderWidth: 2,
    borderColor: Colors.border,
  },
  cardSelected: {
    borderColor: Colors.primary,
    backgroundColor: Colors.goldSoft,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emoji: { fontSize: 24 },
  cardBody: { flex: 1, marginLeft: Spacing.md },
  cardTitle: { fontSize: 16, fontWeight: '700', color: Colors.text },
  cardDesc: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 2,
    lineHeight: 18,
  },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: Colors.border,
  },
  radioOn: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary,
  },
  footer: { marginTop: 'auto', paddingBottom: Spacing.lg },
});
