import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { useAuth } from '@/src/context/AuthContext';

export default function SmsScreen() {
  const { verifySms, pendingPhone } = useAuth();
  const [phone, setPhone] = useState(pendingPhone ?? '+998');
  const [code, setCode] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const sendSms = () => {
    setSent(true);
  };

  const verify = async () => {
    setLoading(true);
    const ok = await verifySms(code || '1234');
    setLoading(false);
    if (ok) router.push('/(auth)/role');
  };

  return (
    <Screen scroll contentStyle={styles.content}>
      <TouchableOpacity onPress={() => router.back()} style={styles.back}>
        <Text style={styles.backText}>← Orqaga qaytish</Text>
      </TouchableOpacity>

      <View style={styles.iconWrap}>
        <Text style={styles.icon}>🔒</Text>
      </View>
      <Text style={styles.title}>Parolni tiklash</Text>
      <Text style={styles.subtitle}>
        Telefon raqamingizni kiriting,{'\n'}unga SMS orqali kod yuboramiz.
      </Text>

      <View style={styles.card}>
        <Input
          label="Telefon raqami"
          placeholder="+998 90 123 45 67"
          keyboardType="phone-pad"
          value={phone}
          onChangeText={setPhone}
          leftElement={<Text style={styles.prefix}>🇺🇿</Text>}
        />

        {!sent ? (
          <Button title="SMS yuborish" onPress={sendSms} />
        ) : (
          <>
            <Input
              label="SMS kod"
              placeholder="4–6 raqam"
              keyboardType="number-pad"
              value={code}
              onChangeText={setCode}
              maxLength={6}
            />
            <Button title="Tasdiqlash" onPress={verify} loading={loading} />
            <TouchableOpacity onPress={sendSms} style={styles.resend}>
              <Text style={styles.resendText}>Kodni qayta yuborish</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      <TouchableOpacity
        style={styles.apply}
        onPress={() => router.push('/venue-apply')}
      >
        <Text style={styles.applyTitle}>Hisobingiz yo'qmi?</Text>
        <Text style={styles.applyLink}>Yangi to'yxona uchun ariza qoldiring →</Text>
      </TouchableOpacity>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingTop: Spacing.lg,
  },
  back: {
    marginBottom: Spacing.lg,
  },
  backText: {
    color: Colors.primary,
    fontSize: 15,
    fontWeight: '500',
  },
  iconWrap: {
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  icon: {
    fontSize: 48,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginTop: Spacing.sm,
    marginBottom: Spacing.xl,
    lineHeight: 20,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  prefix: {
    fontSize: 18,
  },
  resend: {
    marginTop: Spacing.md,
    alignItems: 'center',
  },
  resendText: {
    color: Colors.primary,
    fontSize: 14,
  },
  apply: {
    marginTop: Spacing.xl,
    backgroundColor: Colors.goldSoft,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    alignItems: 'center',
  },
  applyTitle: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
  applyLink: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.primaryDark,
    marginTop: 4,
  },
});
