import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { MOCK_BOOKINGS, formatMoney } from '@/src/data/mock';
import type { BookingStatus } from '@/src/types';

const FILTERS: { key: BookingStatus | 'all'; label: string }[] = [
  { key: 'all', label: 'Barchasi' },
  { key: 'confirmed', label: 'Tasdiqlangan' },
  { key: 'deposit', label: 'Zakalat' },
  { key: 'completed', label: 'Yak' },
];

export default function BookingsScreen() {
  const [filter, setFilter] = useState<BookingStatus | 'all'>('all');

  const data = useMemo(() => {
    if (filter === 'all') return MOCK_BOOKINGS;
    return MOCK_BOOKINGS.filter((b) => b.status === filter);
  }, [filter]);

  return (
    <Screen contentStyle={styles.content}>
      <Text style={styles.pageTitle}>Bronlar</Text>

      <View style={styles.filters}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.chip, filter === f.key && styles.chipActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[styles.chipText, filter === f.key && styles.chipTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => router.push(`/booking/${item.id}`)}
          >
            <Card style={styles.card}>
              <View style={styles.row}>
                <Text style={styles.date}>
                  {formatDate(item.date)}, {item.time}
                </Text>
                <Badge status={item.status} />
              </View>
              <Text style={styles.type}>
                {item.typeLabel} · {item.guestCount} mehmon
              </Text>
              <Text style={styles.client}>{item.clientName}</Text>
              <Text style={styles.phone}>{item.clientPhone}</Text>
              <Text style={styles.amount}>{formatMoney(item.totalAmount)}</Text>
            </Card>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>Bronlar topilmadi</Text>
        }
      />

      <View style={styles.fab}>
        <Button title="+ Yangi bron" onPress={() => {}} />
      </View>
    </Screen>
  );
}

function formatDate(iso: string) {
  const [y, m, d] = iso.split('-');
  const months = [
    '', 'Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyn',
    'Iyl', 'Avg', 'Sen', 'Okt', 'Noy', 'Dek',
  ];
  return `${parseInt(d, 10)} ${months[parseInt(m, 10)]} ${y}`;
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md, flex: 1 },
  pageTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.md,
  },
  filters: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: Spacing.md,
    flexWrap: 'wrap',
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  chipActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  chipText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  chipTextActive: { color: Colors.white },
  card: { marginBottom: Spacing.sm },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  date: { fontSize: 14, fontWeight: '600', color: Colors.text },
  type: { fontSize: 13, color: Colors.textSecondary },
  client: { fontSize: 15, fontWeight: '600', color: Colors.text, marginTop: 6 },
  phone: { fontSize: 13, color: Colors.textMuted, marginTop: 2 },
  amount: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.primaryDark,
    marginTop: 8,
  },
  empty: {
    textAlign: 'center',
    color: Colors.textMuted,
    marginTop: 40,
  },
  fab: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    right: 16,
  },
});
