import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { MOCK_BOOKINGS } from '@/src/data/mock';

const WEEKDAYS = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya'];
const MONTH_NAMES = [
  'Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun',
  'Iyul', 'Avgust', 'Sentabr', 'Oktabr', 'Noyabr', 'Dekabr',
];

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfWeek(year: number, month: number) {
  const d = new Date(year, month, 1).getDay();
  return d === 0 ? 6 : d - 1; // Monday = 0
}

export default function CalendarScreen() {
  const [cursor, setCursor] = useState(new Date(2026, 9, 1)); // Oct 2026
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDow = getFirstDayOfWeek(year, month);

  const busyDates = useMemo(() => {
    const map: Record<string, string> = {};
    MOCK_BOOKINGS.forEach((b) => {
      map[b.date] = b.status === 'completed' ? 'completed' : 'busy';
    });
    return map;
  }, []);

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prev = () => setCursor(new Date(year, month - 1, 1));
  const next = () => setCursor(new Date(year, month + 1, 1));

  const todayEvents = MOCK_BOOKINGS.filter((b) => b.date === '2026-10-12');

  return (
    <Screen scroll contentStyle={styles.content}>
      <Text style={styles.pageTitle}>Kalendar</Text>

      <Card>
        <View style={styles.monthNav}>
          <TouchableOpacity onPress={prev} style={styles.navBtn}>
            <Text style={styles.navText}>‹</Text>
          </TouchableOpacity>
          <Text style={styles.monthTitle}>
            {MONTH_NAMES[month]} {year}
          </Text>
          <TouchableOpacity onPress={next} style={styles.navBtn}>
            <Text style={styles.navText}>›</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.weekRow}>
          {WEEKDAYS.map((w) => (
            <Text key={w} style={styles.weekDay}>
              {w}
            </Text>
          ))}
        </View>

        <View style={styles.grid}>
          {cells.map((day, idx) => {
            if (day === null) {
              return <View key={`e-${idx}`} style={styles.dayCell} />;
            }
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const status = busyDates[dateStr];
            const isSelected = day === 12 && month === 9;
            return (
              <TouchableOpacity
                key={dateStr}
                style={[
                  styles.dayCell,
                  isSelected && styles.daySelected,
                  status === 'busy' && styles.dayBusy,
                  status === 'completed' && styles.dayDone,
                ]}
              >
                <Text
                  style={[
                    styles.dayNum,
                    isSelected && styles.dayNumSelected,
                    status && styles.dayNumBusy,
                  ]}
                >
                  {day}
                </Text>
                {status ? <View style={[styles.dot, status === 'completed' && styles.dotDone]} /> : null}
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={styles.legend}>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: Colors.success }]} />
            <Text style={styles.legendText}>Bo'sh</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: Colors.warning }]} />
            <Text style={styles.legendText}>Band</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: Colors.info }]} />
            <Text style={styles.legendText}>Tadbir tugagan</Text>
          </View>
        </View>
      </Card>

      <Text style={[styles.sectionTitle, { marginTop: Spacing.lg }]}>Bugungi tadbirlar</Text>
      {todayEvents.length === 0 ? (
        <Text style={styles.empty}>Bugun tadbir yo'q</Text>
      ) : (
        todayEvents.map((b) => (
          <Card key={b.id} style={styles.eventItem}>
            <Text style={styles.eventTime}>
              {b.time} · {b.typeLabel}
            </Text>
            <Text style={styles.eventGuests}>{b.guestCount} mehmon</Text>
          </Card>
        ))
      )}

      {/* Sample for design match */}
      <Card style={styles.eventItem}>
        <Text style={styles.eventTime}>11:00 · Nikoh</Text>
        <Text style={styles.eventGuests}>150 mehmon</Text>
      </Card>
      <Card style={styles.eventItem}>
        <Text style={styles.eventTime}>18:00 · To'y</Text>
        <Text style={styles.eventGuests}>400 mehmon</Text>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md },
  pageTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.md,
  },
  monthNav: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  navBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  navText: { fontSize: 22, color: Colors.primary, fontWeight: '600' },
  monthTitle: { fontSize: 17, fontWeight: '700', color: Colors.text },
  weekRow: { flexDirection: 'row', marginBottom: 8 },
  weekDay: {
    flex: 1,
    textAlign: 'center',
    fontSize: 12,
    fontWeight: '600',
    color: Colors.textMuted,
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayCell: {
    width: '14.28%',
    aspectRatio: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: Radius.sm,
  },
  daySelected: { backgroundColor: Colors.primary },
  dayBusy: { backgroundColor: Colors.warningBg },
  dayDone: { backgroundColor: Colors.infoBg },
  dayNum: { fontSize: 14, color: Colors.text, fontWeight: '500' },
  dayNumSelected: { color: Colors.white, fontWeight: '700' },
  dayNumBusy: { fontWeight: '600' },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: Colors.warning,
    marginTop: 2,
  },
  dotDone: { backgroundColor: Colors.info },
  legend: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
    marginTop: Spacing.md,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontSize: 12, color: Colors.textSecondary },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.sm,
  },
  empty: { color: Colors.textMuted, fontSize: 14 },
  eventItem: { marginBottom: Spacing.sm },
  eventTime: { fontSize: 15, fontWeight: '600', color: Colors.text },
  eventGuests: { fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
});
