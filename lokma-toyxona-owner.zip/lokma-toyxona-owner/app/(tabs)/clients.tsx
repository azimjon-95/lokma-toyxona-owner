import React, { useState, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, TextInput } from 'react-native';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { Badge } from '@/src/components/ui/Badge';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { MOCK_CLIENTS } from '@/src/data/mock';
import type { BookingStatus } from '@/src/types';

const FILTERS: { key: BookingStatus | 'all'; label: string }[] = [
  { key: 'all', label: 'Barchasi' },
  { key: 'confirmed', label: 'Yangi' },
  { key: 'deposit', label: 'Tadbir bo\'yicha' },
];

export default function ClientsScreen() {
  const [filter, setFilter] = useState<BookingStatus | 'all'>('all');
  const [q, setQ] = useState('');

  const data = useMemo(() => {
    let list = MOCK_CLIENTS;
    if (filter !== 'all') list = list.filter((c) => c.status === filter);
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter(
        (c) => c.name.toLowerCase().includes(s) || c.phone.includes(s)
      );
    }
    return list;
  }, [filter, q]);

  return (
    <Screen contentStyle={styles.content}>
      <Text style={styles.pageTitle}>Mijozlar</Text>

      <View style={styles.searchBox}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Mijoz qidirish..."
          placeholderTextColor={Colors.textMuted}
          value={q}
          onChangeText={setQ}
        />
      </View>

      <View style={styles.filters}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.chip, filter === f.key && styles.chipActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[styles.chipText, filter === f.key && styles.chipTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <View style={styles.row}>
              <View style={styles.avatar}>
                <Text style={{ fontSize: 18 }}>👤</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.phone}>{item.phone}</Text>
                {item.lastEvent ? (
                  <Text style={styles.meta}>{item.lastEvent}</Text>
                ) : null}
              </View>
              <Badge status={item.status} />
            </View>
          </Card>
        )}
        ListEmptyComponent={
          <Text style={styles.empty}>Mijozlar topilmadi</Text>
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md, flex: 1 },
  pageTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.md,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.md,
    height: 48,
  },
  searchIcon: { marginRight: 8, fontSize: 16 },
  searchInput: { flex: 1, fontSize: 15, color: Colors.text },
  filters: { flexDirection: 'row', gap: 8, marginBottom: Spacing.md },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  chipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  chipTextActive: { color: Colors.white },
  card: { marginBottom: Spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: { fontSize: 15, fontWeight: '600', color: Colors.text },
  phone: { fontSize: 13, color: Colors.textMuted, marginTop: 2 },
  meta: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  empty: { textAlign: 'center', color: Colors.textMuted, marginTop: 40 },
});
