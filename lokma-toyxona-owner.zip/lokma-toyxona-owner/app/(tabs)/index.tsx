import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { useAuth } from '@/src/context/AuthContext';
import { MOCK_TODAY_EVENT, MOCK_BOOKINGS, formatMoney } from '@/src/data/mock';

export default function HomeScreen() {
  const { user } = useAuth();
  const nextBooking = MOCK_BOOKINGS.find(
    (b) => b.status === 'pending' || b.status === 'confirmed'
  );

  return (
    <Screen scroll contentStyle={styles.content}>
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <View style={styles.logoMini}>
            <Text style={{ fontSize: 18 }}>🏛️</Text>
          </View>
          <View>
            <Text style={styles.brand}>Lokma</Text>
            <Text style={styles.brandSub}>To'yxonalar</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <Text style={styles.userName}>{user?.name ?? 'Foydalanuvchi'}</Text>
          <Text style={styles.userRole}>
            {user?.role === 'owner' ? "To'yxona egasi" : 'Xodim'}
          </Text>
        </View>
      </View>

      <Card style={styles.eventCard} padded={false}>
        <View style={styles.eventBanner}>
          <Text style={styles.eventLabel}>Bugungi tadbir</Text>
          <Text style={styles.eventTitle}>{MOCK_TODAY_EVENT.title}</Text>
          <Text style={styles.eventMeta}>
            {MOCK_TODAY_EVENT.guestCount} mehmon · {MOCK_TODAY_EVENT.timeRange}
          </Text>
          <TouchableOpacity style={styles.detailsBtn}>
            <Text style={styles.detailsBtnText}>Tafsilotlar</Text>
          </TouchableOpacity>
        </View>
      </Card>

      <View style={styles.statsRow}>
        <Card style={styles.statCard}>
          <Text style={styles.statLabel}>Bugungi tushum</Text>
          <Text style={styles.statValue}>{formatMoney(8500000)}</Text>
          <Text style={styles.statGrowth}>↑ 12%</Text>
        </Card>
        <Card style={styles.statCard}>
          <Text style={styles.statLabel}>Kutayotgan to'lov</Text>
          <Text style={[styles.statValue, { fontSize: 16 }]}>
            {formatMoney(12000000)}
          </Text>
          <Text style={styles.statSub}>2 ta mijoz</Text>
        </Card>
      </View>

      {nextBooking && (
        <Card style={styles.nextCard}>
          <View style={styles.nextRow}>
            <View style={styles.nextAvatar}>
              <Text style={{ fontSize: 20 }}>💒</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.nextLabel}>Keyingi to'y</Text>
              <Text style={styles.nextTitle}>
                15 Oktabr 2026 · {nextBooking.guestCount} mehmon
              </Text>
            </View>
            <TouchableOpacity
              style={styles.smallBtn}
              onPress={() => router.push(`/booking/${nextBooking.id}`)}
            >
              <Text style={styles.smallBtnText}>Kirish</Text>
            </TouchableOpacity>
          </View>
        </Card>
      )}

      <Button
        title="+ Yangi bron"
        onPress={() => router.push('/(tabs)/bookings')}
        style={{ marginTop: Spacing.md }}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoMini: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brand: { fontSize: 18, fontWeight: '700', color: Colors.primaryDark },
  brandSub: { fontSize: 12, color: Colors.primary },
  headerRight: { alignItems: 'flex-end' },
  userName: { fontSize: 14, fontWeight: '600', color: Colors.text },
  userRole: { fontSize: 11, color: Colors.textMuted },
  eventCard: { marginBottom: Spacing.md, overflow: 'hidden' },
  eventBanner: {
    backgroundColor: Colors.primaryDark,
    minHeight: 140,
    padding: Spacing.md,
    justifyContent: 'flex-end',
  },
  eventLabel: { color: Colors.goldSoft, fontSize: 12, fontWeight: '500' },
  eventTitle: { color: Colors.white, fontSize: 22, fontWeight: '700', marginTop: 2 },
  eventMeta: { color: 'rgba(255,255,255,0.85)', fontSize: 13, marginTop: 4 },
  detailsBtn: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.full,
    marginTop: 10,
  },
  detailsBtnText: { color: Colors.white, fontSize: 12, fontWeight: '600' },
  statsRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.md },
  statCard: { flex: 1 },
  statLabel: { fontSize: 12, color: Colors.textSecondary },
  statValue: { fontSize: 18, fontWeight: '700', color: Colors.text, marginTop: 4 },
  statGrowth: { fontSize: 12, color: Colors.success, marginTop: 2 },
  statSub: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  nextCard: { marginBottom: Spacing.sm },
  nextRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  nextAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextLabel: { fontSize: 12, color: Colors.textSecondary },
  nextTitle: { fontSize: 14, fontWeight: '600', color: Colors.text },
  smallBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.md,
  },
  smallBtnText: { color: Colors.white, fontSize: 13, fontWeight: '600' },
});
