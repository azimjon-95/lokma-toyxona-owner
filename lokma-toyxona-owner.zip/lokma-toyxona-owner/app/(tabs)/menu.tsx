import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { MOCK_MENUS, formatMoney } from '@/src/data/mock';

type Tab = 'packages' | 'dishes';

export default function MenuScreen() {
  const [tab, setTab] = useState<Tab>('packages');

  return (
    <Screen contentStyle={styles.content}>
      <Text style={styles.pageTitle}>Menyu</Text>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, tab === 'packages' && styles.tabActive]}
          onPress={() => setTab('packages')}
        >
          <Text style={[styles.tabText, tab === 'packages' && styles.tabTextActive]}>
            Menyu paketlari
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, tab === 'dishes' && styles.tabActive]}
          onPress={() => setTab('dishes')}
        >
          <Text style={[styles.tabText, tab === 'dishes' && styles.tabTextActive]}>
            Taomlar
          </Text>
        </TouchableOpacity>
      </View>

      {tab === 'packages' ? (
        <FlatList
          data={MOCK_MENUS}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 100 }}
          renderItem={({ item }) => (
            <Card style={styles.card}>
              <View style={styles.row}>
                <View style={styles.thumb}>
                  <Text style={{ fontSize: 28 }}>🍲</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.name}>{item.name}</Text>
                  <Text style={styles.price}>
                    {formatMoney(item.pricePerPerson)} / 1 kishi
                  </Text>
                  <Text style={styles.range}>{item.guestRange}</Text>
                </View>
              </View>
            </Card>
          )}
        />
      ) : (
        <View style={styles.emptyBox}>
          <Text style={styles.emptyIcon}>🥗</Text>
          <Text style={styles.emptyText}>Taomlar ro'yxati tez orada</Text>
        </View>
      )}

      <View style={styles.fab}>
        <Button title="+ Yangi menyu" onPress={() => {}} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md, flex: 1 },
  pageTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.md,
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: Colors.creamDark,
    borderRadius: Radius.md,
    padding: 4,
    marginBottom: Spacing.md,
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: Radius.sm,
  },
  tabActive: { backgroundColor: Colors.white },
  tabText: { fontSize: 14, fontWeight: '600', color: Colors.textSecondary },
  tabTextActive: { color: Colors.primaryDark },
  card: { marginBottom: Spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  thumb: {
    width: 64,
    height: 64,
    borderRadius: Radius.md,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: { fontSize: 16, fontWeight: '700', color: Colors.text },
  price: { fontSize: 14, color: Colors.primaryDark, fontWeight: '600', marginTop: 4 },
  range: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  emptyBox: { alignItems: 'center', marginTop: 60 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { color: Colors.textMuted, fontSize: 15 },
  fab: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    right: 16,
  },
});
