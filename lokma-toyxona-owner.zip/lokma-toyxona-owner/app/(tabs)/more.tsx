import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Card } from '@/src/components/ui/Card';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { useAuth } from '@/src/context/AuthContext';

const ITEMS = [
  { icon: '💰', title: 'Moliya', href: '/finance' },
  { icon: '📝', title: "Yangi to'yxona arizasi", href: '/venue-apply' },
  { icon: '👥', title: 'Xodimlar', href: null },
  { icon: '⚙️', title: 'Sozlamalar', href: null },
  { icon: '📞', title: "Yordam va qo'llab-quvvatlash", href: null },
  { icon: '📄', title: 'Maxfiylik siyosati', href: null },
];

export default function MoreScreen() {
  const { user, logout } = useAuth();

  const onLogout = () => {
    Alert.alert('Chiqish', 'Hisobdan chiqmoqchimisiz?', [
      { text: 'Bekor', style: 'cancel' },
      {
        text: 'Chiqish',
        style: 'destructive',
        onPress: () => {
          logout();
          router.replace('/(auth)/login');
        },
      },
    ]);
  };

  return (
    <Screen scroll contentStyle={styles.content}>
      <Text style={styles.pageTitle}>More</Text>

      <Card style={styles.profile}>
        <View style={styles.avatar}>
          <Text style={{ fontSize: 28 }}>👤</Text>
        </View>
        <View>
          <Text style={styles.name}>{user?.name ?? 'Foydalanuvchi'}</Text>
          <Text style={styles.phone}>{user?.phone}</Text>
          <Text style={styles.role}>
            {user?.role === 'owner' ? "To'yxona egasi" : 'Xodim'}
          </Text>
        </View>
      </Card>

      {ITEMS.map((item) => (
        <TouchableOpacity
          key={item.title}
          style={styles.item}
          onPress={() => {
            if (item.href) router.push(item.href as any);
            else Alert.alert(item.title, 'Tez orada...');
          }}
        >
          <Text style={styles.itemIcon}>{item.icon}</Text>
          <Text style={styles.itemTitle}>{item.title}</Text>
          <Text style={styles.chevron}>›</Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity style={styles.logout} onPress={onLogout}>
        <Text style={styles.logoutText}>Chiqish</Text>
      </TouchableOpacity>

      <Text style={styles.version}>Lokma To'yxonalar v1.0.0</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md },
  pageTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.md,
  },
  profile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: Spacing.lg,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.goldSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: { fontSize: 17, fontWeight: '700', color: Colors.text },
  phone: { fontSize: 13, color: Colors.textMuted, marginTop: 2 },
  role: { fontSize: 12, color: Colors.primary, marginTop: 2, fontWeight: '500' },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  itemIcon: { fontSize: 20, marginRight: 12 },
  itemTitle: { flex: 1, fontSize: 15, fontWeight: '500', color: Colors.text },
  chevron: { fontSize: 22, color: Colors.textMuted },
  logout: {
    marginTop: Spacing.lg,
    alignItems: 'center',
    padding: Spacing.md,
  },
  logoutText: { color: Colors.danger, fontSize: 16, fontWeight: '600' },
  version: {
    textAlign: 'center',
    color: Colors.textMuted,
    fontSize: 12,
    marginTop: Spacing.md,
  },
});
