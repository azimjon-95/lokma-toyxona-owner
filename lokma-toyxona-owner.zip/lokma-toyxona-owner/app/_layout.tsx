import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '@/src/context/AuthContext';
import { Colors } from '@/src/theme/colors';

export { ErrorBoundary } from 'expo-router';

export default function RootLayout() {
  return (
    <AuthProvider>
      <StatusBar style="dark" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: Colors.cream },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen name="index" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen
          name="booking/[id]"
          options={{ headerShown: true, title: 'Bron tafsilotlari', headerBackTitle: 'Orqaga' }}
        />
        <Stack.Screen name="venue-apply/index" options={{ headerShown: false }} />
        <Stack.Screen name="venue-apply/step2" options={{ headerShown: false }} />
        <Stack.Screen name="venue-apply/step3" options={{ headerShown: false }} />
        <Stack.Screen name="finance" options={{ headerShown: true, title: 'Moliya' }} />
      </Stack>
    </AuthProvider>
  );
}
