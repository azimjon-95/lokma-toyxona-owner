import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking, Alert } from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { Card } from '@/src/components/ui/Card';
import { Badge } from '@/src/components/ui/Badge';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { MOCK_BOOKINGS, formatMoney } from '@/src/data/mock';

export default function BookingDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const booking = MOCK_BOOKINGS.find((b) => b.id === id) ?? MOCK_BOOKINGS[0];

  const call = () => {
    if (booking.clientPhone) {
      Linking.openURL(`tel:${booking.clientPhone.replace(/\s/g, '')}`);
    }
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Bron tafsilotlari',
          headerStyle: { backgroundColor: Colors.cream },
          headerTintColor: Colors.primaryDark,
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.date}>
              {booking.date.split('-').reverse().join('.')} , {booking.time}
            </Text>
            <Text style={styles.type}>
              {booking.typeLabel} · {booking.guestCount} mehmon
            </Text>
          </View>
          <Badge status={booking.status} />
        </View>

        <Card style={styles.moneyCard}>
          <View style={styles.moneyRow}>
            <View>
              <Text style={styles.moneyLabel}>Jami summa</Text>
              <Text style={styles.moneyValue}>{formatMoney(booking.totalAmount)}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.moneyLabel}>Zakalat</Text>
              <Text style={[styles.moneyValue, { fontSize: 16 }]}>
                {formatMoney(booking.depositAmount)}
              </Text>
            </View>
          </View>
        </Card>

        {/* Tabs mock */}
        <View style={styles.tabs}>
          {['Ma\'lumot', 'Menyu', "To'lovlar", 'Xodimlar'].map((t, i) => (
            <TouchableOpacity key={t} style={[styles.tab, i === 0 && styles.tabActive]}>
              <Text style={[styles.tabText, i === 0 && styles.tabTextActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Card>
          <Text style={styles.sectionTitle}>Mijoz ma'lumotlari</Text>
          <View style={styles.clientRow}>
            <View style={styles.avatar}>
              <Text style={{ fontSize: 22 }}>👤</Text>
            </View>
            <View>
              <Text style={styles.clientName}>{booking.clientName}</Text>
              <Text style={styles.clientPhone}>{booking.clientPhone}</Text>
              {booking.notes ? (
                <Text style={styles.notes}>{booking.notes}</Text>
              ) : null}
            </View>
          </View>
        </Card>

        {booking.menuName && (
          <Card style={{ marginTop: Spacing.sm }}>
            <Text style={styles.sectionTitle}>Menyu</Text>
            <Text style={styles.menuName}>{booking.menuName}</Text>
            {booking.menuPricePerPerson ? (
              <Text style={styles.menuPrice}>
                {formatMoney(booking.menuPricePerPerson)} / 1 kishi
              </Text>
            ) : null}
          </Card>
        )}

        <View style={styles.actions}>
          <Button
            title="To'lov qabul qilish"
            onPress={() => Alert.alert('To\'lov', 'Demo: to\'lov qabul qilindi')}
            style={{ flex: 1 }}
            fullWidth={false}
          />
          <TouchableOpacity style={styles.callBtn} onPress={call}>
            <Text style={styles.callIcon}>📞</Text>
            <Text style={styles.callText}>Qo'ng'iroq</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.bottomActions}>
          <TouchableOpacity style={styles.bottomItem}>
            <Text>✈️ Telegram</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.bottomItem}>
            <Text>✏️ Tahrirlash</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.bottomItem}>
            <Text>🧾 Chek</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.cream },
  content: { padding: Spacing.md, paddingBottom: 40 },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: Spacing.md,
  },
  date: { fontSize: 18, fontWeight: '700', color: Colors.text },
  type: { fontSize: 14, color: Colors.textSecondary, marginTop: 4 },
  moneyCard: { marginBottom: Spacing.md, backgroundColor: Colors.goldSoft },
  moneyRow: { flexDirection: 'row', justifyContent: 'space-between' },
  moneyLabel: { fontSize: 12, color: Colors.textSecondary },
  moneyValue: { fontSize: 20, fontWeight: '700', color: Colors.primaryDark, marginTop: 4 },
  tabs: {
    flexDirection: 'row',
    marginBottom: Spacing.md,
    gap: 4,
  },
  tab: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  tabActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  tabText: { fontSize: 12, fontWeight: '600', color: Colors.textSecondary },
  tabTextActive: { color: Colors.white },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.textMuted,
    marginBottom: 10,
    textTransform: 'uppercase',
  },
  clientRow: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  clientName: { fontSize: 16, fontWeight: '700', color: Colors.text },
  clientPhone: { fontSize: 13, color: Colors.textMuted, marginTop: 2 },
  notes: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  menuName: { fontSize: 16, fontWeight: '600', color: Colors.text },
  menuPrice: { fontSize: 14, color: Colors.primaryDark, marginTop: 4 },
  actions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: Spacing.lg,
    alignItems: 'center',
  },
  callBtn: {
    backgroundColor: Colors.info,
    borderRadius: Radius.md,
    paddingHorizontal: 16,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 6,
  },
  callIcon: { fontSize: 16 },
  callText: { color: Colors.white, fontWeight: '600', fontSize: 14 },
  bottomActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: Spacing.lg,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  bottomItem: { padding: 8 },
});
