import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Stack } from 'expo-router';
import { Card } from '@/src/components/ui/Card';
import { Colors, Spacing, Radius } from '@/src/theme/colors';
import { MOCK_FINANCE, MOCK_TRANSACTIONS, formatMoney } from '@/src/data/mock';

type Tab = 'all' | 'income' | 'expense';

export default function FinanceScreen() {
  const [tab, setTab] = useState<Tab>('all');
  const f = MOCK_FINANCE;

  const txs = MOCK_TRANSACTIONS.filter((t) => {
    if (tab === 'income') return t.type === 'income' || t.type === 'deposit';
    if (tab === 'expense') return t.type === 'expense';
    return true;
  });

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Moliya',
          headerStyle: { backgroundColor: Colors.cream },
          headerTintColor: Colors.primaryDark,
        }}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.tabs}>
          {[
            { key: 'all' as Tab, label: 'Barchasi' },
            { key: 'income' as Tab, label: 'Daromad' },
            { key: 'expense' as Tab, label: 'Xarajat' },
          ].map((t) => (
            <TouchableOpacity
              key={t.key}
              style={[styles.tab, tab === t.key && styles.tabActive]}
              onPress={() => setTab(t.key)}
            >
              <Text style={[styles.tabText, tab === t.key && styles.tabTextActive]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Card style={styles.summary}>
          <Text style={styles.summaryLabel}>Jami tushum</Text>
          <Text style={styles.summaryValue}>{formatMoney(f.totalRevenue)}</Text>
          <Text style={styles.growth}>↑ {f.growthPercent}% o'tgan oyga nisbatan</Text>

          <View style={styles.split}>
            <View style={styles.splitItem}>
              <Text style={styles.splitLabel}>Zakalat</Text>
              <Text style={styles.splitValue}>{formatMoney(f.deposit)}</Text>
            </View>
            <View style={styles.splitItem}>
              <Text style={styles.splitLabel}>To'langan</Text>
              <Text style={styles.splitValue}>{formatMoney(f.paid)}</Text>
            </View>
            <View style={styles.splitItem}>
              <Text style={styles.splitLabel}>Qoldiq</Text>
              <Text style={[styles.splitValue, { color: Colors.warning }]}>
                {formatMoney(f.remaining)}
              </Text>
            </View>
          </View>
        </Card>

        <Text style={styles.sectionTitle}>So'nggi operatsiyalar</Text>
        {txs.map((t) => (
          <Card key={t.id} style={styles.tx}>
            <View style={styles.txRow}>
              <View style={styles.txIcon}>
                <Text>
                  {t.type === 'expense' ? '📤' : t.type === 'deposit' ? '💳' : '📥'}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.txTitle}>{t.title}</Text>
                <Text style={styles.txDate}>{t.date}</Text>
              </View>
              <Text
                style={[
                  styles.txAmount,
                  t.amount < 0 && { color: Colors.danger },
                  t.type === 'deposit' && { color: Colors.warning },
                ]}
              >
                {t.amount > 0 ? '+' : ''}
                {formatMoney(t.amount)}
              </Text>
            </View>
          </Card>
        ))}
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.cream },
  content: { padding: Spacing.md, paddingBottom: 40 },
  tabs: { flexDirection: 'row', gap: 8, marginBottom: Spacing.md },
  tab: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  tabActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  tabText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  tabTextActive: { color: Colors.white },
  summary: {
    backgroundColor: Colors.success,
    marginBottom: Spacing.lg,
  },
  summaryLabel: { fontSize: 13, color: 'rgba(255,255,255,0.85)' },
  summaryValue: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.white,
    marginTop: 4,
  },
  growth: { fontSize: 13, color: 'rgba(255,255,255,0.9)', marginTop: 4 },
  split: {
    flexDirection: 'row',
    marginTop: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.25)',
  },
  splitItem: { flex: 1 },
  splitLabel: { fontSize: 11, color: 'rgba(255,255,255,0.75)' },
  splitValue: {
    fontSize: 13,
    fontWeight: '700',
    color: Colors.white,
    marginTop: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: Spacing.sm,
  },
  tx: { marginBottom: Spacing.sm },
  txRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  txIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  txTitle: { fontSize: 14, fontWeight: '600', color: Colors.text },
  txDate: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  txAmount: { fontSize: 14, fontWeight: '700', color: Colors.success },
});
