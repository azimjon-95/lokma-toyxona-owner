import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';

export default function VenueApplyStep1() {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');

  return (
    <Screen scroll contentStyle={styles.content}>
      <TouchableOpacity onPress={() => router.back()} style={styles.back}>
        <Text style={styles.backText}>← Orqaga</Text>
      </TouchableOpacity>

      <View style={styles.hero}>
        <Text style={styles.heroIcon}>🏛️</Text>
        <Text style={styles.heroTitle}>Yangi to'yxona uchun ariza qoldirish</Text>
        <Text style={styles.heroSub}>
          To'yxona ochmoqchimisiz? Biz bilan bog'laning, sizga yordam beramiz.
        </Text>
      </View>

      <View style={styles.steps}>
        {[1, 2, 3].map((s) => (
          <View key={s} style={[styles.stepDot, s === 1 && styles.stepActive]}>
            <Text style={[styles.stepNum, s === 1 && styles.stepNumActive]}>{s}</Text>
          </View>
        ))}
      </View>
      <Text style={styles.stepLabel}>1. Asosiy ma'lumotlar</Text>

      <View style={styles.card}>
        <Input
          label="To'yxona nomi *"
          placeholder="Masalan: Oltin Saroy"
          value={name}
          onChangeText={setName}
        />
        <Input
          label="Manzil *"
          placeholder="Toshkent, Chilonzor tumani"
          value={address}
          onChangeText={setAddress}
        />
        <Input
          label="Telefon raqami *"
          placeholder="+998 90 123 45 67"
          keyboardType="phone-pad"
          value={phone}
          onChangeText={setPhone}
        />
        <Button
          title="Keyingi"
          onPress={() => router.push('/venue-apply/step2')}
          disabled={!name || !address || !phone}
        />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md },
  back: { marginBottom: Spacing.md },
  backText: { color: Colors.primary, fontSize: 15, fontWeight: '500' },
  hero: { alignItems: 'center', marginBottom: Spacing.lg },
  heroIcon: { fontSize: 40, marginBottom: 8 },
  heroTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.text,
    textAlign: 'center',
  },
  heroSub: {
    fontSize: 13,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 18,
    paddingHorizontal: 12,
  },
  steps: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 8,
  },
  stepDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepActive: { backgroundColor: Colors.primary },
  stepNum: { fontSize: 14, fontWeight: '700', color: Colors.textMuted },
  stepNumActive: { color: Colors.white },
  stepLabel: {
    textAlign: 'center',
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
});
