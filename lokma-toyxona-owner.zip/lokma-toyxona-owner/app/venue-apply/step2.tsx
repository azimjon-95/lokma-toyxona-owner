import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';

const SERVICES = ['Oshpaz', 'Ofitsiant', 'Dekor', 'Musiqa', 'Foto/Video'];

export default function VenueApplyStep2() {
  const [halls, setHalls] = useState('2');
  const [capacity, setCapacity] = useState('300');
  const [selected, setSelected] = useState<string[]>(['Oshpaz', 'Ofitsiant']);

  const toggle = (s: string) => {
    setSelected((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );
  };

  return (
    <Screen scroll contentStyle={styles.content}>
      <TouchableOpacity onPress={() => router.back()} style={styles.back}>
        <Text style={styles.backText}>← Orqaga</Text>
      </TouchableOpacity>

      <View style={styles.steps}>
        {[1, 2, 3].map((s) => (
          <View key={s} style={[styles.stepDot, s <= 2 && styles.stepActive]}>
            <Text style={[styles.stepNum, s <= 2 && styles.stepNumActive]}>{s}</Text>
          </View>
        ))}
      </View>
      <Text style={styles.stepLabel}>2. Zal va imkoniyatlar</Text>

      <View style={styles.card}>
        <Input
          label="Zallar soni"
          keyboardType="number-pad"
          value={halls}
          onChangeText={setHalls}
        />
        <Input
          label="Stol sig'imi (kishi)"
          keyboardType="number-pad"
          value={capacity}
          onChangeText={setCapacity}
        />

        <Text style={styles.label}>Qo'shimcha xizmatlar</Text>
        <View style={styles.chips}>
          {SERVICES.map((s) => (
            <TouchableOpacity
              key={s}
              style={[styles.chip, selected.includes(s) && styles.chipOn]}
              onPress={() => toggle(s)}
            >
              <Text style={[styles.chipText, selected.includes(s) && styles.chipTextOn]}>
                {s}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Button title="Keyingi" onPress={() => router.push('/venue-apply/step3')} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md },
  back: { marginBottom: Spacing.md },
  backText: { color: Colors.primary, fontSize: 15, fontWeight: '500' },
  steps: { flexDirection: 'row', justifyContent: 'center', gap: 12, marginBottom: 8 },
  stepDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepActive: { backgroundColor: Colors.primary },
  stepNum: { fontSize: 14, fontWeight: '700', color: Colors.textMuted },
  stepNumActive: { color: Colors.white },
  stepLabel: {
    textAlign: 'center',
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  label: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
  },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: Spacing.lg },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: Radius.full,
    backgroundColor: Colors.creamDark,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  chipOn: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  chipText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  chipTextOn: { color: Colors.white },
});
