import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/src/components/ui/Screen';
import { Input } from '@/src/components/ui/Input';
import { Button } from '@/src/components/ui/Button';
import { Colors, Spacing, Radius } from '@/src/theme/colors';

export default function VenueApplyStep3() {
  const [priceFrom, setPriceFrom] = useState('100000');
  const [priceTo, setPriceTo] = useState('300000');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      Alert.alert(
        'Ariza yuborildi!',
        "Tez orada operatorlarimiz siz bilan bog'lanadi.",
        [{ text: 'OK', onPress: () => router.replace('/(auth)/login') }]
      );
    }, 800);
  };

  return (
    <Screen scroll contentStyle={styles.content}>
      <TouchableOpacity onPress={() => router.back()} style={styles.back}>
        <Text style={styles.backText}>← Orqaga</Text>
      </TouchableOpacity>

      <View style={styles.steps}>
        {[1, 2, 3].map((s) => (
          <View key={s} style={[styles.stepDot, styles.stepActive]}>
            <Text style={[styles.stepNum, styles.stepNumActive]}>{s}</Text>
          </View>
        ))}
      </View>
      <Text style={styles.stepLabel}>3. Qo'shimcha ma'lumot</Text>

      <View style={styles.card}>
        <Text style={styles.label}>Foto (galereya)</Text>
        <TouchableOpacity style={styles.photoBox}>
          <Text style={{ fontSize: 32 }}>📷</Text>
          <Text style={styles.photoText}>Rasmlar qo'shish</Text>
        </TouchableOpacity>

        <View style={styles.priceRow}>
          <View style={{ flex: 1 }}>
            <Input
              label="Narx dan (so'm/kishi)"
              keyboardType="number-pad"
              value={priceFrom}
              onChangeText={setPriceFrom}
            />
          </View>
          <View style={{ width: 12 }} />
          <View style={{ flex: 1 }}>
            <Input
              label="gacha"
              keyboardType="number-pad"
              value={priceTo}
              onChangeText={setPriceTo}
            />
          </View>
        </View>

        <Input
          label="Izoh"
          placeholder="Qo'shimcha ma'lumot..."
          value={notes}
          onChangeText={setNotes}
          multiline
          numberOfLines={3}
          style={{ minHeight: 80, textAlignVertical: 'top' }}
        />

        <Button title="Ariza yuborish" onPress={submit} loading={loading} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: Spacing.md },
  back: { marginBottom: Spacing.md },
  backText: { color: Colors.primary, fontSize: 15, fontWeight: '500' },
  steps: { flexDirection: 'row', justifyContent: 'center', gap: 12, marginBottom: 8 },
  stepDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.creamDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepActive: { backgroundColor: Colors.primary },
  stepNum: { fontSize: 14, fontWeight: '700', color: Colors.textMuted },
  stepNumActive: { color: Colors.white },
  stepLabel: {
    textAlign: 'center',
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: Radius.xl,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  label: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
  },
  photoBox: {
    height: 100,
    borderRadius: Radius.md,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
    backgroundColor: Colors.inputBg,
  },
  photoText: { fontSize: 13, color: Colors.textMuted, marginTop: 4 },
  priceRow: { flexDirection: 'row' },
});
