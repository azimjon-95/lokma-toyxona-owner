import React, { createContext, useContext, useMemo, useState, useCallback } from 'react';
import type { User, UserRole } from '../types';
import { MOCK_USER } from '../data/mock';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (phone: string, password: string) => Promise<boolean>;
  verifySms: (code: string) => Promise<boolean>;
  setRole: (role: UserRole) => void;
  logout: () => void;
  pendingPhone: string | null;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading] = useState(false);
  const [pendingPhone, setPendingPhone] = useState<string | null>(null);

  const login = useCallback(async (phone: string, _password: string) => {
    // Demo: any non-empty phone works
    if (!phone || phone.length < 9) return false;
    setPendingPhone(phone);
    return true;
  }, []);

  const verifySms = useCallback(async (code: string) => {
    if (code.length < 4) return false;
    // After SMS, go to role selection — user not fully set yet
    return true;
  }, []);

  const setRole = useCallback((role: UserRole) => {
    setUser({
      ...MOCK_USER,
      phone: pendingPhone ?? MOCK_USER.phone,
      role,
    });
  }, [pendingPhone]);

  const logout = useCallback(() => {
    setUser(null);
    setPendingPhone(null);
  }, []);

  const value = useMemo(
    () => ({
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      verifySms,
      setRole,
      logout,
      pendingPhone,
    }),
    [user, isLoading, login, verifySms, setRole, logout, pendingPhone]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
