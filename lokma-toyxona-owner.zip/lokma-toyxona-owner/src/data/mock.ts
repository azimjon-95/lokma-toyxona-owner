import type {
  Booking,
  Client,
  MenuPackage,
  FinanceSummary,
  FinanceTransaction,
  TodayEvent,
  User,
  Venue,
} from '../types';

export const MOCK_USER: User = {
  id: 'u1',
  phone: '+998901234567',
  name: 'Azimjon',
  role: 'owner',
  venueId: 'v1',
  venueName: "To'yxonalar",
};

export const MOCK_VENUE: Venue = {
  id: 'v1',
  name: "Oltin Saroy",
  address: "Toshkent, Chilonzor tumani",
  phone: '+998 90 123 45 67',
  hallsCount: 3,
  capacity: 500,
};

export const MOCK_TODAY_EVENT: TodayEvent = {
  title: "To'y",
  type: "To'y",
  guestCount: 150,
  timeRange: '18:00 – 23:00',
};

export const MOCK_BOOKINGS: Booking[] = [
  {
    id: 'b1',
    date: '2026-10-12',
    time: '18:00',
    endTime: '23:00',
    type: 'toy',
    typeLabel: "To'y",
    guestCount: 400,
    clientName: 'Azizbek & Dilshoda',
    clientPhone: '+998 90 123 45 67',
    status: 'confirmed',
    totalAmount: 74_000_000,
    depositAmount: 2_000_000,
    paidAmount: 72_000_000,
    menuName: "To'y №3",
    menuPricePerPerson: 185_000,
    hallName: 'Katta zal',
    notes: 'Toshkent, Chilonzor',
  },
  {
    id: 'b2',
    date: '2026-10-18',
    time: '17:00',
    type: 'nikoh',
    typeLabel: 'Nikoh',
    guestCount: 150,
    clientName: 'Sardor & Madina',
    clientPhone: '+998 93 987 65 43',
    status: 'deposit',
    totalAmount: 120_000_000,
    depositAmount: 12_000_000,
    paidAmount: 12_000_000,
  },
  {
    id: 'b3',
    date: '2026-10-25',
    time: '18:00',
    type: 'toy',
    typeLabel: "To'y",
    guestCount: 500,
    clientName: 'Bekzod & Shaxlo',
    clientPhone: '+998 94 456 78 90',
    status: 'completed',
    totalAmount: 200_000_000,
    depositAmount: 20_000_000,
    paidAmount: 200_000_000,
  },
  {
    id: 'b4',
    date: '2026-10-15',
    time: '18:00',
    type: 'toy',
    typeLabel: "To'y",
    guestCount: 180,
    clientName: 'Keyingi to\'y',
    clientPhone: '+998 90 111 22 33',
    status: 'pending',
    totalAmount: 33_300_000,
    depositAmount: 0,
    paidAmount: 0,
  },
];

export const MOCK_CLIENTS: Client[] = [
  {
    id: 'c1',
    name: 'Azizbek & Dilshoda',
    phone: '+998 90 123 45 67',
    status: 'confirmed',
    lastEvent: "To'y · 400 mehmon",
    date: '12 Okt, 18:00',
  },
  {
    id: 'c2',
    name: 'Sardor & Madina',
    phone: '+998 93 987 65 43',
    status: 'deposit',
    lastEvent: 'Nikoh · 150 mehmon',
    date: '18 Okt, 17:00',
  },
  {
    id: 'c3',
    name: 'Bekzod & Shaxlo',
    phone: '+998 94 456 78 90',
    status: 'completed',
    lastEvent: "To'y · 500 mehmon",
    date: '25 Okt, 18:00',
  },
  {
    id: 'c4',
    name: 'Javohir & Ziyoda',
    phone: '+998 97 111 22 33',
    status: 'cancelled',
    lastEvent: "To'y · 300 mehmon",
    date: '—',
  },
];

export const MOCK_MENUS: MenuPackage[] = [
  {
    id: 'm1',
    name: "To'y №1",
    pricePerPerson: 120_000,
    guestRange: '200 mehmon',
  },
  {
    id: 'm2',
    name: "To'y №2",
    pricePerPerson: 150_000,
    guestRange: '350 mehmon',
  },
  {
    id: 'm3',
    name: "To'y №3",
    pricePerPerson: 185_000,
    guestRange: '400+ mehmon',
  },
  {
    id: 'm4',
    name: 'Premium',
    pricePerPerson: 220_000,
    guestRange: '500+ mehmon',
  },
];

export const MOCK_FINANCE: FinanceSummary = {
  totalRevenue: 85_300_000,
  deposit: 14_000_000,
  paid: 62_000_000,
  remaining: 23_500_000,
  growthPercent: 12,
};

export const MOCK_TRANSACTIONS: FinanceTransaction[] = [
  {
    id: 't1',
    title: "To'yona (naqd)",
    date: '12 Okt, 18:20',
    amount: 12_500_000,
    type: 'income',
  },
  {
    id: 't2',
    title: 'Zakalat',
    date: '12 Okt, 18:10',
    amount: 2_000_000,
    type: 'deposit',
  },
  {
    id: 't3',
    title: 'Xarajat (ovqat mahsulotlari)',
    date: '12 Okt, 16:30',
    amount: -3_500_000,
    type: 'expense',
  },
];

export function formatMoney(n: number): string {
  const abs = Math.abs(n);
  const s = abs.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return n < 0 ? `-${s} so'm` : `${s} so'm`;
}

export function statusLabel(status: string): string {
  const map: Record<string, string> = {
    confirmed: 'Tasdiqlangan',
    deposit: 'Zakalat kutilmoqda',
    pending: 'Kutilmoqda',
    completed: 'Yakunlangan',
    cancelled: 'Bekor qilingan',
  };
  return map[status] ?? status;
}

export function statusColor(status: string): { bg: string; text: string } {
  const map: Record<string, { bg: string; text: string }> = {
    confirmed: { bg: '#E8F5E9', text: '#2E7D32' },
    deposit: { bg: '#FFF8E1', text: '#F9A825' },
    pending: { bg: '#E3F2FD', text: '#1565C0' },
    completed: { bg: '#E8EAF6', text: '#3949AB' },
    cancelled: { bg: '#FFEBEE', text: '#C62828' },
  };
  return map[status] ?? { bg: '#F5F5F5', text: '#666' };
}
