export const Colors = {
  primary: '#B8860B',       // gold/bronze
  primaryDark: '#8B6914',
  primaryLight: '#D4A84B',
  gold: '#C9A227',
  goldSoft: '#F5E6C8',
  cream: '#FBF7F0',
  creamDark: '#F3EBD9',
  white: '#FFFFFF',
  black: '#1A1A1A',
  text: '#2C2C2C',
  textSecondary: '#6B6B6B',
  textMuted: '#9A9A9A',
  border: '#E8E0D0',
  success: '#2E7D32',
  successBg: '#E8F5E9',
  warning: '#F9A825',
  warningBg: '#FFF8E1',
  danger: '#C62828',
  dangerBg: '#FFEBEE',
  info: '#1565C0',
  infoBg: '#E3F2FD',
  card: '#FFFFFF',
  overlay: 'rgba(0,0,0,0.45)',
  tabInactive: '#A0A0A0',
  inputBg: '#F8F4EC',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};
