export type UserRole = 'owner' | 'staff';

export type BookingStatus = 'confirmed' | 'deposit' | 'pending' | 'completed' | 'cancelled';

export type SessionType = 'nikoh' | 'toy' | 'other';

export interface User {
  id: string;
  phone: string;
  name: string;
  role: UserRole;
  venueId?: string;
  venueName?: string;
}

export interface Venue {
  id: string;
  name: string;
  address: string;
  phone: string;
  hallsCount: number;
  capacity: number;
  image?: string;
}

export interface Booking {
  id: string;
  date: string; // YYYY-MM-DD
  time: string;
  endTime?: string;
  type: SessionType;
  typeLabel: string;
  guestCount: number;
  clientName: string;
  clientPhone: string;
  clientAvatar?: string;
  status: BookingStatus;
  totalAmount: number;
  depositAmount: number;
  paidAmount: number;
  menuName?: string;
  menuPricePerPerson?: number;
  hallName?: string;
  notes?: string;
  staff?: StaffMember[];
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  phone?: string;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  status: BookingStatus;
  lastEvent?: string;
  guestCount?: number;
  date?: string;
}

export interface MenuPackage {
  id: string;
  name: string;
  pricePerPerson: number;
  guestRange: string;
  image?: string;
  dishes?: string[];
}

export interface FinanceSummary {
  totalRevenue: number;
  deposit: number;
  paid: number;
  remaining: number;
  growthPercent: number;
}

export interface FinanceTransaction {
  id: string;
  title: string;
  date: string;
  amount: number;
  type: 'income' | 'expense' | 'deposit';
}

export interface CalendarDay {
  date: string;
  status: 'free' | 'busy' | 'completed' | 'partial';
  bookings?: number;
}

export interface TodayEvent {
  title: string;
  type: string;
  guestCount: number;
  timeRange: string;
  image?: string;
}
